// Get the modal
let authModal = document.getElementById("auth-modal");

window.onload = function () {
  authModal.style.display = "block";
};
